# AutoTracer — QGIS Plugin

Converts a scanned, georeferenced raster map into clean line vector features through a five-step automated pipeline.

---

## Pipeline Overview

| Step | Operation | Purpose |
|------|-----------|---------|
| 1 | **Binarization** | Convert image to 1-bit black & white |
| 2 | **Thresholding** | Isolate map lines as solid black on white background |
| 3 | **Smoothing** | Remove salt-and-pepper noise (Median or Gaussian filter) |
| 4 | **Skeletonization** | Thin all lines to single-pixel width |
| 5 | **Vectorization** | Trace raster skeleton → vector polylines |

---

## Requirements

### QGIS
- QGIS 3.16 or later

### Python Dependencies
Install in the OSGeo4W Shell (Windows) or via pip:

```bash
pip install opencv-python scikit-image numpy
```

On Linux/macOS with the QGIS Python environment:
```bash
python3 -m pip install opencv-python scikit-image numpy
```

---

## Installation

1. Copy the entire `raster_to_vector_plugin/` folder into your QGIS plugins directory:
   - **Windows**: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

2. Open QGIS → **Plugins** → **Manage and Install Plugins…**

3. In the **Installed** tab, check **AutoTracer**.

4. The plugin appears in the **Raster** menu and toolbar.

---

## Usage

1. Load your georeferenced raster map into QGIS.
2. Open the plugin: **RAutoTracer**.
3. In the **Settings** tab:
   - Select the input raster layer.
   - Choose a **Thresholding** method:
     - *Otsu* — best for most maps (fully automatic).
     - *Adaptive* — better for uneven lighting.
     - *Manual* — set a custom threshold value (0–255).
   - Tick **Invert** if the map lines are lighter than the background.
   - Choose a **Smoothing** filter and kernel size (odd number, 3–21).
   - Enable **Smooth output lines** to apply Douglas-Peucker simplification (removes pixel stair-steps).
   - Set a **Minimum feature length** to discard noise fragments.
4. Click **▶ Run Pipeline**.
5. A new `Extracted Lines` vector layer is added to the project.
6. Use the **Preview** tab to inspect intermediate processing stages.

---

## Tips

- Start with **Otsu** thresholding — it works well for most printed maps.
- If lines are broken or dotted, reduce the **Min feature length** value.
- If the output contains too many short artefacts, increase **Min feature length** and kernel size.
- Tick **Load intermediate raster layers** to debug each pipeline stage.
- For large rasters, processing may take several seconds — a progress bar keeps you informed.

---

## File Structure

```
raster_to_vector_plugin/
├── __init__.py        # QGIS classFactory entry point
├── metadata.txt       # Plugin metadata
├── plugin.py          # Plugin class (menu / toolbar)
├── dialog.py          # Main dialog UI
├── processing.py      # Core 5-step image processing pipeline
├── worker.py          # QThread background worker
└── README.md          # This file
```

---

## License

MIT License — free to use, modify, and distribute.
